export class Section {
  Id = 0;
  Title = '';
  ImagePath = '';
  SectionDescription = '';
  ItemOrder = 0;
}
