export interface Inventory {
    Status: string;
    date: string;
    inventoryId: number;
}
