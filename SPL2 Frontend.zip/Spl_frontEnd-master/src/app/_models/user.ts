﻿export class User {
    // tslint:disable-next-line:variable-name
    access_Level: string;
    email: string;
    password: string;
    passwordHash: null;
    passwordSalt: null;
    phone: string;
    staffId: number;
    token: string;
    username: string;

}
