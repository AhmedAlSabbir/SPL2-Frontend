export interface Student {
        student_Id: number;
        registration: string;
        address: string;
        bloodGroup: string;
        dateOfBirth: string;
        department: string;
        fatherName: string;
        firstname: string;
        hallRoll: string;
        lastname: string;
        motherName: string;
        nationality: string;
        religion: string;
        session: string;
        stuffName: string;
}
